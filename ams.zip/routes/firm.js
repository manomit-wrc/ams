module.exports = function(app, models) {
	

	app.get('/admin/firm',function(req, res){
		models.Admin.belongsTo(models.Firm,{foreignKey: 'firm_id'});
		models.Admin.belongsTo(models.Country,{foreignKey: 'country_id'});
		models.Admin.belongsTo(models.State,{foreignKey: 'state_id'});
		models.Admin.belongsTo(models.City,{foreignKey: 'city_id'});
		models.Admin.belongsTo(models.Designation,{foreignKey: 'designation_id'});

		models.Admin.findAll({
			where: {
		      role_code: 'FIRMADM'
		   },
      		include: [{model: models.Firm},{model: models.Country},{model: models.State},{model: models.City},{model:models.Designation}]
		}
    	).then(function(firms){
      		//console.log(firms);
			res.render('admin/firm/index',{layout:'dashboard', firms:firms});
		});
	});

	app.get('/admin/firm/add', function(req, res){
		Promise.all([
		    models.Designation.findAll({
		      attributes: ['id', 'code'],
		      where: { status: 1 }
		    }),
		    models.Country.findAll(),
		    models.Group.findAll(),
		    models.Section.findAll({attributes: ['id', 'name']}),
		    models.PracticeArea.findAll({attributes: ['id', 'name']}),
		    models.Codemaster.findAll({attributes: ['id', 'shortdescription'],where: {categoryid:7}})

		  ]).then(function(values) {
		    var result = JSON.parse(JSON.stringify(values));
		    
		    res.render('admin/firm/add',{
		    	layout:'dashboard', 
		    	designation:result[0],
		    	country:result[1],
		    	group: result[2],
		    	section: result[3],
		    	practice_area: result[4],
		    	jurisdiction: result[5]
		    });
		  });
	});
};