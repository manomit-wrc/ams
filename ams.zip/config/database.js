module.exports = {
    'connection': {
        'host': '192.168.1.109',
        'user': 'testuser',
        'password': 'grass1=!'
    },
	'database': 'ams'
};