module.exports = {
    development: {
    username: "testuser",
    password: "grass1=!",
    database: "ams",
    host: "192.168.1.109",
    dialect: "mysql",
    logging: false
  },
    production: {
    username: "testuser",
    password: "grass1=!",
    database: "ams",
    host: "192.168.1.109",
    dialect: "mysql"
  },
    staging: {
    username: "testuser",
    password: "grass1=!",
    database: "ams",
    host: "192.168.1.109",
    dialect: "mysql"
  },
    test: {
    username: "testuser",
    password: "grass1=!",
    database: "ams",
    host: "192.168.1.109",
    dialect: "mysql"
  }
};